﻿# startup.sh 启动项目
#!/bin/sh
echo "授予当前用户权限"
chmod 777 /home/soft/fangzhi.jar
echo "执行....."
java -jar /home/soft/fangzhi.jar